package eu.efti.datatools.populate

import eu.efti.datatools.populate.EftiDomPopulator.EnumTypeMatcher
import eu.efti.datatools.populate.EftiDomPopulator.FixedAttributeValueMatcher
import eu.efti.datatools.populate.EftiDomPopulator.SchemaValueMatcher
import eu.efti.datatools.populate.EftiDomPopulator.ValueNameMatcher
import eu.efti.datatools.populate.EftiDomPopulator.ValueTypeMatcher
import eu.efti.datatools.schema.EftiSchemaId
import eu.efti.datatools.schema.XmlSchemaElement.XmlName
import eu.efti.datatools.schema.XmlSchemaElement.XmlType
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Base64
import java.util.Locale

/**
 * The value generators to use for one family of eFTI schemas.
 *
 * @property description human readable name of the schemas these generators are written for, for use in messages
 * @property rules matchers and their generators, in priority order: the first matching rule wins
 */
class ValueGeneratorSet(
    val description: String,
    val rules: List<Pair<SchemaValueMatcher, XmlValueGenerator>>,
) {
    /**
     * The first rule that matches the given element or attribute, looking at its type first and then at its base
     * types, from the most specific to the least specific.
     *
     * @return the matching rule, or null if none of the rules match
     */
    fun findRule(name: XmlName, type: XmlType): Pair<SchemaValueMatcher, XmlValueGenerator>? =
        sequenceOf(type).plus(type.baseTypes)
            .firstNotNullOfOrNull { t -> rules.firstOrNull { it.first.match(name, t) } }
}

/**
 * Value generators of the supported eFTI schemas.
 *
 * The eFTI schema versions are kept strictly apart: each version has its own complete set of rules, and rules are
 * never shared between them. The versions use overlapping vocabulary, so a shared set would both hide which rules
 * belong to which schemas and let a rule written for one version match a type of another. They also need different
 * rule orderings, see [v1].
 *
 * Which set to use is decided by the document element of the schema being populated, see [forRootElement], so no
 * schema version needs to be passed around.
 */
@Suppress("detekt:MagicNumber")
class ValueGenerators(private val gen: EftiValueGeneratorFactory) {
    private val dateTimeFormatter205 = DateTimeFormatter.ofPattern("uuuuMMddHHmmxx")

    private fun enumerationGenerator(): XmlValueGenerator = { valuePath, _, type ->
        gen.forPath(valuePath).nextChoice(
            type.enumerationValues,
        )
    }

    /**
     * Generators of the v0 schemas.
     */
    val v0: ValueGeneratorSet = ValueGeneratorSet(
        description = "eFTI v0",
        rules = listOf(
            ValueNameMatcher("schemeAgencyId") to noArgsGenerator { it.nextToken() },
            ValueNameMatcher("sequenceNumber") to repeatIndexGenerator { repeatIndex -> repeatIndex.toString() },
            ValueTypeMatcher("base64Binary") to noArgsGenerator {
                Base64.getEncoder().encodeToString(it.nextToken().toByteArray())
            },
            ValueTypeMatcher("boolean") to noArgsGenerator { it.nextBoolean().toString() },
            ValueTypeMatcher("DateTimeFormat") to noArgsGenerator {
                // Note: for simplicity, always use the same format
                "205"
            },
            ValueTypeMatcher("DateTime") to noArgsGenerator {
                // Note: for simplicity, always use the same format
                dateTimeFormatter205.format(OffsetDateTime.ofInstant(it.nextInstant(), ZoneOffset.UTC))
            },
            ValueTypeMatcher("decimal") to noArgsGenerator {
                String.format(Locale.UK, "%.2f", it.nextDouble(0.0, 10.0))
            },
            ValueTypeMatcher("Identifier17") to noArgsGenerator { it.nextToken() },
            ValueTypeMatcher("integer") to noArgsGenerator { it.nextInt(1000, 9999).toString() },
            ValueTypeMatcher("string") to noArgsGenerator { it.nextToken(4) },
            EnumTypeMatcher to enumerationGenerator(),
        ),
    )

    /**
     * Generators of the v1 schemas.
     *
     * Note that, unlike in [v0], enumerations must be matched *before* the generic types: a v1 type may be named
     * after the primitive it restricts, for example a type named "string" that only permits enumerated values, so
     * matching by type name first would produce values outside the enumeration.
     *
     * Coverage is still incomplete, so populated v1 documents are not necessarily valid against the schema.
     */
    val v1: ValueGeneratorSet = ValueGeneratorSet(
        description = "eFTI v1",
        rules = listOf(
            // An id whose schemeID is fixed to the RFC 9562 version 4 scheme must hold a version 4 UUID. This must
            // be matched before the generic types, because the underlying type is a plain token.
            FixedAttributeValueMatcher("schemeID", UUID_V4_SCHEME_ID) to noArgsGenerator {
                it.nextUuid().toString()
            },
            // The content of a DateTimeString element. Its companion "format" attribute is an enumeration, so it is
            // generated by the enumeration rule below.
            ValueTypeMatcher("DateTimeDateTimeStringContentType") to noArgsGenerator {
                // Note: as in v0, the exact date/time format code is not modelled, the same format is always used.
                dateTimeFormatter205.format(OffsetDateTime.ofInstant(it.nextInstant(), ZoneOffset.UTC))
            },
            EnumTypeMatcher to enumerationGenerator(),
            ValueTypeMatcher(
                "token_4",
                "urn:eu:move:eFTI:data:standard:UnqualifiedDataType:34",
            ) to noArgsGenerator { it.nextToken(1, 3) },
            ValueTypeMatcher(
                "token_33",
                "urn:eu:move:eFTI:data:standard:UnqualifiedDataType:34",
            ) to noArgsGenerator { it.nextToken(2) },
            ValueTypeMatcher(
                "token_3",
                "urn:eu:move:eFTI:data:standard:QualifiedDataType:34",
            ) to noArgsGenerator { it.nextToken(1, 3) },
            ValueTypeMatcher(
                "token_4",
                "urn:eu:move:eFTI:data:standard:QualifiedDataType:34",
            ) to noArgsGenerator { it.nextToken(2) },
            ValueTypeMatcher("base64Binary") to noArgsGenerator {
                Base64.getEncoder().encodeToString(it.nextToken().toByteArray())
            },
            ValueTypeMatcher("boolean") to noArgsGenerator { it.nextBoolean().toString() },
            ValueTypeMatcher("decimal") to noArgsGenerator {
                String.format(Locale.UK, "%.2f", it.nextDouble(0.0, 10.0))
            },
            ValueTypeMatcher("anyURI") to noArgsGenerator { "https://example.com/${it.nextToken()}" },
            ValueTypeMatcher("string") to noArgsGenerator { it.nextToken(4) },
        ),
    )

    /**
     * The generators to use for a schema whose document element is [rootElement].
     *
     * The document element identifies the schemas unambiguously: both namespace and local name are matched, because
     * the v0 schemas share the local name `consignment` and differ only by namespace.
     *
     * @throws IllegalArgumentException if no generators are defined for the given document element
     */
    fun forRootElement(rootElement: XmlName): ValueGeneratorSet = when (rootElement) {
        EftiSchemaId.CONSIGNMENT_COMMON.rootElement,
        EftiSchemaId.CONSIGNMENT_IDENTIFIER.rootElement,
        -> v0

        EftiSchemaId.CMDS_RESPONSE_V1.rootElement -> v1

        else -> throw IllegalArgumentException(
            "No value generators are defined for document element \"${rootElement.localPart}\" of namespace" +
                " \"${rootElement.namespaceURI}\". Document elements with generators: " +
                EftiSchemaId.entries.joinToString(", ") { "\"${it.rootElement.localPart}\"" } +
                ".",
        )
    }

    private fun noArgsGenerator(
        block: (gen: EftiValueGeneratorFactory.EftiValueGenerator) -> String,
    ): XmlValueGenerator =
        { valuePath, _, _ -> block(gen.forPath(valuePath)) }

    private fun repeatIndexGenerator(block: (Int) -> String): XmlValueGenerator =
        { _, repeatIndex, _ -> block(repeatIndex) }

    companion object {
        /**
         * Value that the v1 schemas fix for the `schemeID` attribute of ids that hold a version 4 UUID.
         */
        private const val UUID_V4_SCHEME_ID = "RFC 9562-4"
    }
}
